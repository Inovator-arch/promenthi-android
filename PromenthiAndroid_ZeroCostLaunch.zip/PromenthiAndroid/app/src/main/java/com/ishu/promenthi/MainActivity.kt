package com.ishu.promenthi

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF0B1220)
private val Panel = Color(0xFF152338)
private val Mint = Color(0xFF69E0BD)
private val Muted = Color(0xFF93A5BD)
private val Gold = Color(0xFFF4C96B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        setContent { PromenthiApp(this) }
    }
    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("promenthi_timer", "Study timer", NotificationManager.IMPORTANCE_HIGH))
    }
}

@Composable
fun PromenthiApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("promenthi", Context.MODE_PRIVATE) }
    var page by remember { mutableStateOf("Home") }
    var mode by remember { mutableStateOf(prefs.getString("mode", "Pomodoro") ?: "Pomodoro") }
    var focusMins by remember { mutableIntStateOf(prefs.getInt("focus", 50)) }
    var breakMins by remember { mutableIntStateOf(prefs.getInt("break", 10)) }
    var customMins by remember { mutableIntStateOf(prefs.getInt("custom", 45)) }
    var sets by remember { mutableIntStateOf(prefs.getInt("sets", 2)) }
    var completed by remember { mutableIntStateOf(0) }
    var phase by remember { mutableStateOf("Focus session") }
    var seconds by remember { mutableIntStateOf((if (mode == "Pomodoro") focusMins else customMins) * 60) }
    var totalSeconds by remember { mutableIntStateOf(seconds) }
    var running by remember { mutableStateOf(false) }
    var sound by remember { mutableStateOf(prefs.getBoolean("sound", true)) }
    var focusToday by remember { mutableIntStateOf(prefs.getInt(todayKey(), 0)) }
    var focusSecondsToday by remember { mutableIntStateOf(prefs.getInt(todayKey() + "_sec", 0)) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun persist() {
        prefs.edit().putString("mode", mode).putInt("focus", focusMins).putInt("break", breakMins)
            .putInt("custom", customMins).putInt("sets", sets).putBoolean("sound", sound)
            .putInt(todayKey(), focusToday).apply()
    }
    fun reset() {
        running = false
        phase = "Focus session"
        seconds = (if (mode == "Pomodoro") focusMins else customMins) * 60
        totalSeconds = seconds
    }
    fun alert(title: String, message: String) {
        if (sound) {
            val tone = ToneGenerator(AudioManager.STREAM_ALARM, 85)
            repeat(10) { i ->
                android.os.Handler(context.mainLooper).postDelayed({ tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 350) }, i * 1000L)
            }
            android.os.Handler(context.mainLooper).postDelayed({ tone.release() }, 10500L)
        }
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            val n = NotificationCompat.Builder(context, "promenthi_timer")
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(title).setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).build()
            nm.notify(10, n)
        }
    }

    LaunchedEffect(running) {
        while (running && seconds > 0) {
            delay(1000)
            seconds--
            if (phase == "Focus session") {
                focusSecondsToday++
                if (focusSecondsToday >= 60) {
                    focusToday++
                    focusSecondsToday = 0
                }
                prefs.edit().putInt(todayKey(), focusToday).putInt(todayKey() + "_sec", focusSecondsToday).apply()
            }
        }
        if (running && seconds <= 0) {
            running = false
            if (phase == "Focus session" && mode == "Pomodoro") {
                completed++
                if (completed >= sets) {
                    alert("Study plan complete!", "Excellent work. You completed all your planned sets.")
                    phase = "Focus session"
                    seconds = focusMins * 60
                    totalSeconds = seconds
                } else {
                    alert("Focus session complete", "Time for a ${breakMins}-minute break.")
                    phase = "Break time"
                    seconds = breakMins * 60
                    totalSeconds = seconds
                }
            } else if (phase == "Break time") {
                alert("Break is over", "Ready to focus on your next session?")
                phase = "Focus session"
                seconds = focusMins * 60
                totalSeconds = seconds
            } else {
                alert("Focus session complete", "Great work. Your custom session is complete.")
                seconds = customMins * 60
                totalSeconds = seconds
            }
            persist()
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Mint, onPrimary = Bg,
        onBackground = Color(0xFFEDF4FF), onSurface = Color(0xFFEDF4FF)
    )) {
        Column(Modifier.fillMaxSize().background(Bg)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(43.dp).background(Mint, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                    Text("P", color = Bg, fontSize = 26.sp, fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.width(11.dp))
                Column {
                    Text("promenthi", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                    Text("THE ONE APP FOR USEFUL & EFFECTIVE STUDY", color = Muted, fontSize = 8.sp, letterSpacing = 1.sp)
                }
            }
            when (page) {
                "Home" -> LazyColumn(Modifier.weight(1f).padding(horizontal = 18.dp)) {
                    item {
                        Text("YOUR FOCUS SPACE", color = Mint, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                        Text("Make today count.", fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 6.dp))
                        Text("Small focused steps. Remarkable progress.", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(18.dp))
                    }
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("Pomodoro", "Custom").forEach { option ->
                                        FilterChip(selected = mode == option, onClick = {
                                            if (!running) {
                                                mode = option; completed = 0; prefs.edit().putString("mode", mode).apply(); reset()
                                            }
                                        }, label = { Text(option) })
                                    }
                                }
                                Spacer(Modifier.height(16.dp))
                                Text(if (phase == "Break time") "REST & RESET" else phase.uppercase(), color = if (phase == "Break time") Gold else Mint, fontSize = 11.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(12.dp))
                                Box(Modifier.size(235.dp).background(Color(0xFF102033), CircleShape), contentAlignment = Alignment.Center) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("%02d:%02d".format(seconds / 60, seconds % 60), fontSize = 52.sp, fontWeight = FontWeight.ExtraBold)
                                        Text(if (phase == "Break time") "Take a breather" else "One task at a time", color = Muted, fontSize = 11.sp)
                                    }
                                }
                                Spacer(Modifier.height(18.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.CenterVertically) {
                                    OutlinedButton(onClick = { reset() }) { Text("Reset") }
                                    Button(onClick = { running = !running }) { Text(if (running) "Pause" else "Start") }
                                    OutlinedButton(onClick = {
                                        running = false
                                        if (mode == "Pomodoro" && phase == "Focus session") {
                                            completed++
                                            if (completed >= sets) { completed = sets; reset() }
                                            else { phase = "Break time"; seconds = breakMins * 60; totalSeconds = seconds }
                                        } else { phase = "Focus session"; seconds = (if (mode == "Pomodoro") focusMins else customMins) * 60; totalSeconds = seconds }
                                    }) { Text("Skip") }
                                }
                                Spacer(Modifier.height(18.dp))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Sets completed: $completed / ${if (mode == "Pomodoro") sets else 1}", color = Muted, fontSize = 11.sp)
                                    Text("Today: ${focusToday} min", color = Muted, fontSize = 11.sp)
                                }
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                    }
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(18.dp)) {
                                Text("SESSION PLAN", color = Mint, fontSize = 10.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text("How many sets?", color = Muted, fontSize = 13.sp)
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        TextButton(onClick = { sets = (sets - 1).coerceAtLeast(1); persist() }) { Text("−") }
                                        Text("$sets", fontWeight = FontWeight.Bold)
                                        TextButton(onClick = { sets = (sets + 1).coerceAtMost(12); persist() }) { Text("+") }
                                    }
                                }
                                Text("Estimated time: ${sets * (focusMins + breakMins)} minutes including breaks", color = Muted, fontSize = 11.sp)
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF193A3B)), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(18.dp)) {
                                Text("A LITTLE MOTIVATION", color = Mint, fontSize = 10.sp, letterSpacing = 1.5.sp)
                                Spacer(Modifier.height(8.dp))
                                Text("“The secret of getting ahead is getting started.”", fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                                Text("— Mark Twain", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
                            }
                        }
                        Spacer(Modifier.height(20.dp))
                    }
                }
                "Stats" -> {
                    val weekMinutes = (0..6).sumOf { prefs.getInt(dayKey(-it), 0) }
                    val monthMinutes = (0..29).sumOf { prefs.getInt(dayKey(-it), 0) }
                    Column(Modifier.weight(1f).padding(20.dp)) {
                        Text("YOUR JOURNEY", color = Mint, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                        Text("Progress that adds up.", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 6.dp))
                        Spacer(Modifier.height(20.dp))
                        StatTile("TODAY'S FOCUS", "$focusToday min")
                        StatTile("THIS WEEK", "${weekMinutes / 60}h ${weekMinutes % 60}m")
                        StatTile("THIS MONTH", "${monthMinutes / 60}h ${monthMinutes % 60}m")
                        StatTile("CURRENT STREAK", "${currentStreak(prefs)} days")
                        Spacer(Modifier.height(12.dp))
                        Text("WEEKLY PERFORMANCE", color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                            (6 downTo 0).forEach { off ->
                                val v = prefs.getInt(dayKey(-off), 0)
                                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                                    Box(Modifier.width(25.dp).height((v.coerceAtLeast(2) * 1.2f).coerceAtMost(115f).dp).background(Mint, RoundedCornerShape(topStart = 7.dp, topEnd = 7.dp)))
                                    Text(dayLabel(-off), color = Muted, fontSize = 9.sp, modifier = Modifier.padding(top = 5.dp))
                                }
                            }
                        }
                        Spacer(Modifier.height(22.dp))
                        Text("MONTHLY PERFORMANCE · LAST 30 DAYS", color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        Row(Modifier.fillMaxWidth().height(105.dp), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.Bottom) {
                            (29 downTo 0).forEach { off ->
                                val v = prefs.getInt(dayKey(-off), 0)
                                Box(Modifier.weight(1f).fillMaxHeight(v.coerceAtLeast(1).toFloat().div(180f).coerceAtMost(1f)).background(if (v > 0) Mint else Color(0xFF26364A), RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp)))
                            }
                        }
                        Text("Daily focus minutes over the past month", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 7.dp))
                    }
                }
                else -> {
                    LazyColumn(Modifier.weight(1f).padding(20.dp)) {
                        item {
                            Text("MAKE IT YOURS", color = Mint, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                            Text("Settings", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                            Spacer(Modifier.height(20.dp))
                            SettingNumber("Focus duration (minutes)", focusMins, { focusMins = it.coerceIn(1, 180); persist() })
                            SettingNumber("Break duration (minutes)", breakMins, { breakMins = it.coerceIn(1, 60); persist() })
                            SettingNumber("Custom session (minutes)", customMins, { customMins = it.coerceIn(1, 360); persist() })
                            Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Sound alerts", color = Color.White)
                                Switch(checked = sound, onCheckedChange = { sound = it; persist() })
                            }
                            Button(onClick = {
                                if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                                    permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                } else {
                                    val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                                    nm.notify(11, NotificationCompat.Builder(context, "promenthi_timer").setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("Promenthi notifications").setContentText("Notifications are ready.").build())
                                }
                            }, modifier = Modifier.fillMaxWidth()) { Text("Enable notifications") }
                            Spacer(Modifier.height(14.dp))
                            Text("Study data is stored locally on this device.", color = Muted, fontSize = 11.sp)
                            Spacer(Modifier.height(25.dp))
                            Text("MADE BY ISHU", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                        }
                    }
                }
            }
            NavigationBar(containerColor = Color(0xFF101B2A)) {
                listOf("Home", "Stats", "Settings").forEach { item ->
                    NavigationBarItem(selected = page == item, onClick = { page = item }, icon = { Text(when(item) { "Home" -> "⌂"; "Stats" -> "▥"; else -> "⚙" }, fontSize = 19.sp) }, label = { Text(item, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Mint, selectedTextColor = Mint, indicatorColor = Color(0xFF1E3547), unselectedIconColor = Muted, unselectedTextColor = Muted))
                }
            }
        }
    }
}

@Composable
fun StatTile(label: String, value: String) {
    Card(Modifier.fillMaxWidth().padding(bottom = 10.dp), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(label, color = Muted, fontSize = 10.sp)
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun SettingNumber(label: String, value: Int, onChange: (Int) -> Unit) {
    var text by remember(value) { mutableStateOf(value.toString()) }
    Column(Modifier.fillMaxWidth().padding(vertical = 7.dp)) {
        Text(label, color = Muted, fontSize = 12.sp)
        OutlinedTextField(value = text, onValueChange = { input -> text = input.filter(Char::isDigit); text.toIntOrNull()?.let(onChange) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
    }
}

fun currentStreak(prefs: android.content.SharedPreferences): Int {
    val cal = java.util.Calendar.getInstance()
    var count = 0
    repeat(366) {
        val key = "day_" + SimpleDateFormat("yyyyMMdd", Locale.US).format(cal.time)
        if (prefs.getInt(key, 0) > 0) {
            count++
            cal.add(java.util.Calendar.DAY_OF_YEAR, -1)
        } else return count
    }
    return count
}
fun todayKey(): String = "day_" + SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
fun dayKey(offset: Int): String {
    val cal = java.util.Calendar.getInstance()
    cal.add(java.util.Calendar.DAY_OF_YEAR, offset)
    return "day_" + SimpleDateFormat("yyyyMMdd", Locale.US).format(cal.time)
}
fun dayLabel(offset: Int): String {
    val cal = java.util.Calendar.getInstance()
    cal.add(java.util.Calendar.DAY_OF_YEAR, offset)
    return SimpleDateFormat("EE", Locale.US).format(cal.time).take(1)
}
