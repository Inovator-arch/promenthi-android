# Promenthi Android

Native Android starter project for Promenthi (Kotlin + Jetpack Compose).

## Build APK in GitHub Actions (no Android Studio needed)
1. Upload this whole project to a GitHub repository on the `main` branch.
2. Open the repository's **Actions** tab.
3. Select **Build Promenthi Android APK** and click **Run workflow**, or push a commit to `main`.
4. When the run finishes successfully, open the run and download the `Promenthi-debug-APK` artifact.
5. The downloaded ZIP contains `app-debug.apk`. Extract it and install it on an Android phone. Android may ask you to allow installs from that browser or file manager.

## Publish a free download page
The starter landing page is in `docs/index.html`. Before enabling GitHub Pages, replace `REPLACE_OWNER` in that file with your GitHub username. Then open **Settings → Pages**, choose **Deploy from a branch**, select `main` and `/docs`, and save.

For public APK distribution, create a GitHub Release and attach the APK file. The landing page's download button points to the latest release.

## Project details
- Package ID: `com.ishu.promenthi`
- Minimum Android: Android 8.0 (API 26)
- Local study data uses SharedPreferences.
- The current timer implementation runs while the app process remains alive; a production release should add a foreground timer service for reliable countdowns after the app is swiped away or the process is killed.
- This is a starter build and must be tested on real devices before public release.
